import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:mitness/model/login.dart';
import 'package:mitness/model/programs_homescreen.dart';
import 'package:mitness/model/signup.dart';


class RestDataSource {
  String LAGUAGE_CODE = 'languageCode';

  //static final baseURL = 'https://vast-river-32952.herokuapp.com/customers/';
  static final baseURL = 'https://mitnessnew.herokuapp.com/customers/';
  static final userregistrationURL = baseURL +'signup';
  static final userloginURL = baseURL+'login';
  static final programs_homescreenURL ='https://mitnessnew.herokuapp.com/'+'programs';

  Future <signup> doRegistration(String name, String lname, String email, String role, String password) async {
   Map jsonData;
   final client = HttpClient();
   HttpClientRequest request = await client.postUrl(Uri.parse(userregistrationURL));
   request.headers.set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");
   jsonData = {
   "firstname":'$name',
    "lastname":'$lname',
    "email":'$email',
    "role": '$role',
    "password":'$password',
   };
   // request.write('{"username": "AD123","password": "AD123","tokenId": "12345"}');
   request.write(jsonEncode(jsonData));
   print(jsonEncode(jsonData));
   final HttpClientResponse response= await request.close();

   // dynamic reply = await response.transform(utf8.decoder).join();
   var responseBody = await response.transform(utf8.decoder).join();
   Map data = json.decode(responseBody);
   print(data);

   return signup.fromJson(data);

  }

  Future <login> doLogin( String email, String password) async {
    Map jsonData;
    final client = HttpClient();
    HttpClientRequest request = await client.postUrl(Uri.parse(userloginURL));

    request.headers.set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");

    jsonData = {
      "email":'$email',
      "password":'$password',
    };

    // request.write('{"username": "AD123","password": "AD123","tokenId": "12345"}');
    request.write(jsonEncode(jsonData));

    print(jsonEncode(jsonData));
    final HttpClientResponse response= await request.close();

    // dynamic reply = await response.transform(utf8.decoder).join();
    var responseBody = await response.transform(utf8.decoder).join();
    Map data = json.decode(responseBody);
    print(data);

    return login.fromJson(data);

  }

  Future <programs_homescreen> load_homescreen( String email, String password) async {
    Map jsonData;
    final client = HttpClient();
    HttpClientRequest request = await client.postUrl(Uri.parse(programs_homescreenURL));

    request.headers.set(HttpHeaders.contentTypeHeader, "application/json; charset=UTF-8");

    jsonData = {
      "email":'',
      "password":'',
    };

    // request.write('{"username": "AD123","password": "AD123","tokenId": "12345"}');
    request.write(jsonEncode(jsonData));
    print(jsonEncode(jsonData));

    final HttpClientResponse response= await request.close();

    // dynamic reply = await response.transform(utf8.decoder).join();
    var responseBody = await response.transform(utf8.decoder).join();
    Map data = json.decode(responseBody);
    print(data);
    return programs_homescreen.fromJson(data);

  }


}