import 'package:flutter/material.dart';

final primary = Colors.indigo;
final secondary = Colors.black;
final background = Colors.white10;
 