import 'package:flutter/material.dart';

String
LOGIN_SCREEN = '/userlogin',
    SIGN_UP_SCREEN = '/SignUpScreen',
    ANIMATED_SPLASH = '/SplashScreen',
    HOME_SCREEN = '/HomeScreen',
    PHOTO_CONTAINER_SCREEN = '/PracticeScreen',
    VIDEO_CONTAINER_SCREEN = '/CompetitionScreen',
    ALBUM_CONTAINER_SCREEN = '/WinnersScreen';
final String SIGN_IN = 'signin';
final String SIGN_UP ='signup';
final String SPLASH_SCREEN ='splashscreen';



class APPURLS {
  static const String SAMPLE_URL =
      "https://hcicf.lntecc.com/cfservice.svc/";
}

class MESSAGES {
  static const String INTERNET_ERROR = "No Internet Connection";
  static const String INTERNET_ERROR_RETRY =
      "No Internet Connection.\nPlease Retry";
}

class COLORS {
  // App Colors //
  static const Color DRAWER_BG_COLOR = Colors.lightGreen;
  static const Color APP_THEME_COLOR = Colors.green;
}