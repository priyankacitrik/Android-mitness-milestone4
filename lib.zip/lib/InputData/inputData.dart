import 'package:flutter/material.dart';
import 'package:mitness/utils/constants.dart';
import 'package:mitness/validation/validation.dart';


class InputData{

  static Widget buildTitleTF(TextEditingController myText) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
/*
        Text(
          'Name',
          style: kLabelStyle,
        ),
*/
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            textCapitalization: TextCapitalization.words,
            controller: myText,
            style: TextStyle(
              color: const Color(0xff003366),
              fontFamily: 'OpenSans',
            ),
            validator: ValidationData.titleNameValidate,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.person,
                color: const Color(0xff003366),
              ),
              hintText: 'Title',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }

  static Widget buildNameTF(TextEditingController myText) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
/*
        Text(
          'Name',
          style: kLabelStyle,
        ),
*/
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            textCapitalization: TextCapitalization.words,
            controller: myText,
            style: TextStyle(
              color: const Color(0xff003366),
              fontFamily: 'OpenSans',
            ),
            validator: ValidationData.firstNameValidate,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.person,
                color: const Color(0xff003366),
              ),
              hintText: 'First Name',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }


  static Widget buildMidNameTF(TextEditingController myText) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
/*
        Text(
          'Name',
          style: kLabelStyle,
        ),
*/
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            textCapitalization: TextCapitalization.words,
            controller: myText,
            style: TextStyle(
              color: const Color(0xff003366),
              fontFamily: 'OpenSans',
            ),
//            validator: ValidationData.firstNameValidate,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.person,
                color: const Color(0xff003366),
              ),
              hintText: 'Middle Name',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }

  static Widget buildLastNameTF(TextEditingController myText) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
/*
        Text(
          'Name',
          style: kLabelStyle,
        ),
*/
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height: 60.0,
          child: TextFormField(
            textCapitalization: TextCapitalization.words,
            controller: myText,
            style: TextStyle(
              color: const Color(0xfff5f5f5),
              fontFamily: 'OpenSans',
            ),

            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              prefixIcon: Icon(
                Icons.email_outlined,
                color: const Color(0xfff5f5f5),
              ),
              hintText: 'Email id',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }

  static Widget buildEmailTF(TextEditingController myText) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
/*
        Text(
          'Email Address',
          style: kLabelStyle,
        ),
*/
        SizedBox(height: 10.0),
        Container(
          alignment: Alignment.centerLeft,
          decoration: kBoxDecorationStyle,
          height:50.0,
          child: TextFormField(
            textCapitalization: TextCapitalization.words,
            controller: myText,
            keyboardType: TextInputType.text,
            style: TextStyle(
              color: const Color(0xffffffff),
              fontFamily: 'OpenSans',
            ),
            validator: ValidationData.firstNameValidate,
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 14.0),
              suffixIcon: Icon(
                Icons.arrow_drop_down,
                color: const Color(0xffffffff),
              ),
              hintText: '    Role',
              hintStyle: kHintTextStyle,
            ),
          ),
        ),
      ],
    );
  }

 static Widget buildPasswordTF(TextEditingController myText) {
   return Column(
     crossAxisAlignment: CrossAxisAlignment.start,
     children: <Widget>[
/*
       Text(
         'Password',
         style: kLabelStyle,
       ),
*/
       SizedBox(height: 10.0),
       Container(
         alignment: Alignment.centerLeft,
         decoration: kBoxDecorationStyle,
         height: 60.0,
         child:  TextFormField(
           controller: myText,
           obscureText: true,
           style: TextStyle(
             color: const Color(0xffffffff),
             fontFamily: 'OpenSans',
           ),
           validator: ValidationData.passwordValidate,

           decoration: InputDecoration(
             border: InputBorder.none,
             contentPadding: EdgeInsets.only(top: 14.0),
             prefixIcon: Icon(
               Icons.lock,
               color: const Color(0xffffffff),
             ),
             hintText: '  Password',
             hintStyle: kHintTextStyle,
           ),
         ),
       ),
     ],
   );
 }

 static Widget buildNumberTF(TextEditingController myText) {
   return Column(
     crossAxisAlignment: CrossAxisAlignment.start,
     children: <Widget>[
/*
       Text(
         'Phone Number',
         style: kLabelStyle,
       ),
*/
       SizedBox(height: 10.0),
       Container(
         alignment: Alignment.centerLeft,
         decoration: kBoxDecorationStyle,
         height: 60.0,
         child:  TextFormField(
           controller: myText,
           keyboardType: TextInputType.number,
           obscureText: false,
           style: TextStyle(
             color: const Color(0xfff5f5f5),
             fontFamily: 'OpenSans',

           ),
           validator: ValidationData.mobileValidate,
           decoration: InputDecoration(
             border: InputBorder.none,
             contentPadding: EdgeInsets.only(top: 14.0),
             prefixIcon: Icon(
               Icons.call,
               color: const Color(0xfff5f5f5),
             ),
             hintText: 'Mobile Number',
             hintStyle: kHintTextStyle,
           ),
         ),
       ),
     ],
   );
 }

 static Widget buildLoginBtn(var buttonTitle, Function function) {
   return Container(
    //  height: 90,
     padding: EdgeInsets.only(right: 40,left: 40,bottom: 15),
     width: double.infinity,
     child: RaisedButton(
       elevation: 5.0,
       onPressed: () {
         function();
       },
       padding: EdgeInsets.all(15.0),
       shape: RoundedRectangleBorder(
         borderRadius: BorderRadius.circular(30.0),
       ),
       color: const Color(0xff003366),
       child: Text(
         buttonTitle,
         style: TextStyle(
           color: const Color(0xffffffff),
           letterSpacing: 1.5,
           fontSize: 18.0,
           fontWeight: FontWeight.bold,
           fontFamily: 'OpenSans',
         ),
       ),
     ),
   );
 }

 static Widget buildSignupSigninBtn(var quetion, var pageName, Function function) {
   return Padding(padding: EdgeInsets.only(bottom: 0,top: 5),child: GestureDetector(
     onTap: () {
       function();
     },
     child: RichText(
       text: TextSpan(
         children: [
           TextSpan(
             text: quetion,
             style: TextStyle(
               color: Colors.white,
               fontSize: 18.0,
               fontWeight: FontWeight.w400,
             ),
           ),
           TextSpan(
             text: pageName,
             style: TextStyle(
               color: Colors.white,
               fontSize: 18.0,
               fontWeight: FontWeight.bold,
             ),
           ),
         ],
       ),
     ),
   ),);
 }

 static Widget yourAppbar(var title, Icon icon, Function function){
    return AppBar(
      centerTitle: true,
      backgroundColor: Color(0xFF73AEF5),
      title: Text(title,style: TextStyle(
        color: Colors.white,
        fontFamily: 'OpenSans',
        fontWeight: FontWeight.bold,
      ),),
      actions: <Widget>[
        IconButton(icon: icon, onPressed: (){
          function();
        })
      ],
    );
 }

}