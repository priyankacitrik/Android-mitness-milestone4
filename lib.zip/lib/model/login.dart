class login {
  String code;
  String msg;
  String id;

  login({this.code, this.msg, this.id});

  login.fromJson(Map<String, dynamic> json) {
    code = json['Code'];
    msg = json['Msg'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Code'] = this.code;
    data['Msg'] = this.msg;
    data['id'] = this.id;
    return data;
  }
}

