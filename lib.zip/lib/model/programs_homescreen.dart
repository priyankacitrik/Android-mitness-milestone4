class programs_homescreen {
  List<ProgramResult> programResult;

  programs_homescreen({this.programResult});

  programs_homescreen.fromJson(Map<String, dynamic> json) {
    if (json['ProgramResult'] != null) {
      programResult = new List<ProgramResult>();
      json['ProgramResult'].forEach((v) {
        programResult.add(new ProgramResult.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.programResult != null) {
      data['ProgramResult'] =
          this.programResult.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ProgramResult {
  String classname;
  String image;
  String description;
  String duration;
  String price;
  String totalexercises;

  ProgramResult(
      {this.classname,
        this.image,
        this.description,
        this.duration,
        this.price,
        this.totalexercises});

  ProgramResult.fromJson(Map<String, dynamic> json) {
    classname = json['classname'];
    image = json['image'];
    description = json['description'];
    duration = json['duration'];
    price = json['price'];
    totalexercises = json['totalexercises'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['classname'] = this.classname;
    data['image'] = this.image;
    data['description'] = this.description;
    data['duration'] = this.duration;
    data['price'] = this.price;
    data['totalexercises'] = this.totalexercises;
    return data;
  }
}

