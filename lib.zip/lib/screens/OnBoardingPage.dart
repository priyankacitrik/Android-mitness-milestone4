import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:dots_indicator/dots_indicator.dart';
import 'package:mitness/screens/loginscreen.dart';
import 'package:mitness/slider_componets/introduction_screen.dart';
import 'package:mitness/slider_componets/model/page_decoration.dart';
import 'package:mitness/slider_componets/model/page_view_model.dart';



class OnBoardingPage extends StatefulWidget {
  @override
  _OnBoardingPageState createState() => _OnBoardingPageState();
}

class _OnBoardingPageState extends State<OnBoardingPage> {
  final introKey = GlobalKey<IntroductionScreenState>();

  void _onIntroEnd(context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => LoginScreen()),
    );
  }

  Widget _buildImage(String assetName) {
    return  Container(
      height: double.maxFinite, //// USE THIS FOR THE MATCH WIDTH AND HEIGHT
      width: double.maxFinite,
      decoration: BoxDecoration(

      ),
      child: Image.asset('assets/images/$assetName.jpg',
        fit: BoxFit.fill,),
    );

      Align(

      alignment: Alignment.topCenter,
    );
  }

  @override
  Widget build(BuildContext context) {

    const pageDecoration = const PageDecoration(

      descriptionPadding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
      pageColor: Colors.white,
      imagePadding: EdgeInsets.zero,
    );

    return IntroductionScreen(
      key: introKey,
      pages: [
        PageViewModel(
          title: "",
          body:
          "",
          image: _buildImage('img1'),
          decoration: pageDecoration,
        ),
        PageViewModel(
          title: "Loreum Ipsum",
          body:
          "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Nullam feugiat eu ipsum vel viverra.",
          image: _buildImage('img1'),
          decoration: pageDecoration,
        ),
        PageViewModel(
          title: "Loreum Ipsum",
          body:
          "Lorem ipsum dolor sit amet,consectetur adipiscing elit. Nullam feugiat eu ipsum vel viverra.",
          image: _buildImage('img1'),
          decoration: pageDecoration,
        ),


      ],
      onDone: () => _onIntroEnd(context),
      //onSkip: () => _onIntroEnd(context), // You can override onSkip callback
      showSkipButton: true,
      skipFlex: 0,
      nextFlex: 0,
      skip: const Text('Skip'),
      next: const Icon(Icons.arrow_forward),
      done: const Text('Done', style: TextStyle(fontWeight: FontWeight.w600)),
      dotsDecorator: const DotsDecorator(
        size: Size(10.0, 10.0),
        color: Color(0xFFBDBDBD),
        activeSize: Size(22.0, 10.0),
        activeShape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(25.0)),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: const Center(child: Text("This is the screen after Introduction")),
    );
  }
}
