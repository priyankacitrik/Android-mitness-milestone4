import 'package:carousel_slider/carousel_slider.dart';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mitness/screens/section_title.dart';
import 'package:mitness/utils/size_config.dart';
import 'package:mitness/widgets/CategoryItem.dart';

import 'contents.dart';
import 'homescreen.dart';

class LisofProgramsScreen extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<LisofProgramsScreen> with TickerProviderStateMixin  {
  List bannerAdSlider = [
    "assets/banner1.jpg",
    "assets/banner2.jpg",
    "assets/banner3.jpg",
    "assets/banner4.jpg",

  ];

  List<String> gridItems = [
    'Yoga',
    'Cycling',
    'Welness',
    'Meditation',
    'Yoga',
    'Cycling',
    'Welness',
    'Meditation',

  ];
  int _selectedIndex = 0;
  var my_color_variable =Colors.pinkAccent;

  _onSelected(int index) {
    setState(() => _selectedIndex = index);
  }

  GlobalKey<ScaffoldState> drawerKey = GlobalKey();
  TabController tabController;

  @override
  Widget build(BuildContext context) {
    tabController = new TabController(length: 3, vsync: this);
    return Scaffold(
      backgroundColor: Colors.black54,
      key: drawerKey,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Lis of Programs",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.black54,
        brightness: Brightness.light,
        elevation: 0,
        actionsIconTheme: IconThemeData(color: Colors.black),
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton(
          onPressed: () {},
          icon: Icon(EvaIcons.search),
        ),
        actions: <Widget>[
          IconButton(
            onPressed: () {
              drawerKey.currentState.openDrawer();
            },
            icon: Icon(
              EvaIcons.menu,
              color: Colors.pinkAccent,
            ),
          ),
        ],
      ),
      drawerEdgeDragWidth: 0,
        drawer: Theme(
          data: Theme.of(context).copyWith(
            canvasColor: Colors.black.withOpacity(.9), //This will change the drawer background to blue.
            //other styles
          ),

          child:  Drawer(
            child: ListView(
              children: <Widget>[
                UserAccountsDrawerHeader(
                  decoration: BoxDecoration(
                    color: Colors.pinkAccent.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(5),
                  ),
                  accountEmail: Text(
                    "person@mail.com",
                    style: TextStyle(
                      color: Colors.black,
                    ),
                  ),
                  accountName: Text(
                    "Allice",
                    style: TextStyle(
                      color: Colors.black,
                    ),
                  ),
                  currentAccountPicture: ClipRRect(
                    borderRadius: BorderRadius.circular(70),
                    child: Image(
                      image: NetworkImage(
                          "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"),
                      width: 70,
                      height: 70,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                ListTile(
                    title: Text("Home",  style: TextStyle(
                      color: Colors.pinkAccent,
                    ),),
                    leading: Icon(EvaIcons.homeOutline,color: Colors.white,),
                    onTap: (){
                      Navigator.of(context).pushReplacement(
                          new MaterialPageRoute(builder: (context) => new HomeScreen()));

                    }
                ),
                SizedBox(height: 10),
                ListTile(
                    title: Text("List Of Programs",  style: TextStyle(
                      color: Colors.pinkAccent,
                    ),),
                    leading: Icon(EvaIcons.personOutline,color: Colors.white,),
                    onTap: (){
                      Navigator.of(context).pushReplacement(
                          new MaterialPageRoute(builder: (context) => new LisofProgramsScreen()));

                    }
                ),
                SizedBox(height: 10),
                ListTile(
                    title: Text("Contens",  style: TextStyle(
                      color: Colors.pinkAccent,
                    ),),
                    leading: Icon(EvaIcons.bulbOutline,color: Colors.white,),
                    onTap: (){
                      Navigator.of(context).pushReplacement(
                          new MaterialPageRoute(builder: (context) => new ContentsScreen()));

                    }
                ),
                SizedBox(height: 10),
                ListTile(
                  title: Text("Discover",  style: TextStyle(
                    color: Colors.pinkAccent,
                  ),),
                  leading: Icon(EvaIcons.heartOutline,color: Colors.white,),
                ),
                SizedBox(height: 20),
                /*  Padding(
              padding: const EdgeInsets.all(8.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: AspectRatio(
                  aspectRatio: 16 / 5,
                  child: Image.asset(
                    "assets/banner8.jpg",
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),*/
              ],
            ),
          ),),
        body: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              _tabSection(context),
            ],
          ),
        )
    );





  }

  Widget _tabSection(BuildContext context) {
    return DefaultTabController(
      length: 3,

      child: Column(

        children: <Widget>[
          Container(
           child: Card(
               elevation: 5,
               shape: Border(bottom: BorderSide(color: Colors.white10, width: 3),top: BorderSide(color: Colors.white10, width: 3),),
                color: Colors.transparent,

            child: TabBar(
                indicatorColor: Colors.purple,
                indicatorWeight: 5,

                tabs: [
              Tab(text: "ATHLETS"),
              Tab(text: "ALL COURSES"),
              Tab(text: "FREE"),
            ])),
          ),
          Container(
            //Add this to give height
            height: MediaQuery.of(context).size.height,
            child: TabBarView(children: [
              Container(
                child:  Column(children: [

                  Container(
                    height: 800,
                    child: Container(

                      child: ListView.builder(
                          scrollDirection: Axis.vertical,
                          itemCount: bannerAdSlider.length, itemBuilder: (context, index) {



                        return AspectRatio(
                            aspectRatio: 2,
                            child:
                          GestureDetector(
                            child: Container(


                              margin: EdgeInsets.only(top: 15),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  image: DecorationImage(
                                    image: AssetImage(bannerAdSlider[index]),
                                    fit: BoxFit.cover,
                                  )),
                              child: Container(
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color:
                                    const Color(0xFF000000).withOpacity(0.5)),
                                child: Padding(
                                  padding: EdgeInsets.all(20.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: Text(
                                          "09:48 am",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15,
                                          ),
                                        ),
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            "\@saranjohn",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 15,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                            "10 mins full body stretch",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 14),
                                          )
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ));
                      }),






                    ),)

                ]),
              ),
              Container(
                child: Column(children: [

                  Container(
                    height: 800,
                    child: Container(

                      child: ListView.builder(
                          scrollDirection: Axis.vertical,
                          itemCount: bannerAdSlider.length, itemBuilder: (context, index) {



                        return AspectRatio(
                            aspectRatio: 2,
                            child:
                            GestureDetector(
                              child: Container(


                                margin: EdgeInsets.only(top: 15),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    image: DecorationImage(
                                      image: AssetImage(bannerAdSlider[index]),
                                      fit: BoxFit.cover,
                                    )),
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color:
                                      const Color(0xFF000000).withOpacity(0.5)),
                                  child: Padding(
                                    padding: EdgeInsets.all(20.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Text(
                                            "09:48 am",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 15,
                                            ),
                                          ),
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                              "\@saranjohn",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 15,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                              "10 mins full body stretch",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 14),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ));
                      }),






                    ),)

                ]),
              ),
              Container(
                child: Column(children: [

                  Container(
                    height: 800,
                    child: Container(

                      child: ListView.builder(
                          scrollDirection: Axis.vertical,
                          itemCount: bannerAdSlider.length, itemBuilder: (context, index) {



                        return AspectRatio(
                            aspectRatio: 2,
                            child:
                            GestureDetector(
                              child: Container(


                                margin: EdgeInsets.only(top: 15),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    image: DecorationImage(
                                      image: AssetImage(bannerAdSlider[index]),
                                      fit: BoxFit.cover,
                                    )),
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color:
                                      const Color(0xFF000000).withOpacity(0.5)),
                                  child: Padding(
                                    padding: EdgeInsets.all(20.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Align(
                                          alignment: Alignment.topRight,
                                          child: Text(
                                            "09:48 am",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 15,
                                            ),
                                          ),
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                              "\@saranjohn",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 15,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 5,
                                            ),
                                            Text(
                                              "10 mins full body stretch",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 14),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ));
                      }),






                    ),)

                ]),
              ),
            ]),
          ),
        ],
      ),
    );
  }


  @override
  void didChangeDependencies() {











    
  }

  var listItem = new ListView.builder(
    itemCount: 20,
    itemBuilder: (BuildContext context, int index) {
      return new ListTile(
        title: new Card(
          elevation: 5.0,
          child: new Container(
            alignment: Alignment.center,
            margin: new EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: new Text("ListItem $index"),
          ),
        ),
        onTap: () {
          showDialog(
              barrierDismissible: false,
              context: context,
              child: new CupertinoAlertDialog(
                title: new Column(
                  children: <Widget>[
                    new Text("ListView"),
                    new Icon(
                      Icons.favorite,
                      color: Colors.red,
                    ),
                  ],
                ),
                content: new Text("Selected Item $index"),
                actions: <Widget>[
                  new FlatButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: new Text("OK"))
                ],
              ));
        },
      );
    },
  );

  var gridView = new GridView.builder(
      itemCount: 20,
      gridDelegate:
      new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
      itemBuilder: (BuildContext context, int index) {
        return new GestureDetector(
          child: new Card(
            elevation: 5.0,
            child: new Container(
              alignment: Alignment.center,
              child: new Text('Item $index'),
            ),
          ),
          onTap: () {
            showDialog(
              barrierDismissible: false,
              context: context,
              child: new CupertinoAlertDialog(
                title: new Column(
                  children: <Widget>[
                    new Text("GridView"),
                    new Icon(
                      Icons.favorite,
                      color: Colors.green,
                    ),
                  ],
                ),
                content: new Text("Selected Item $index"),
                actions: <Widget>[
                  new FlatButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: new Text("OK"))
                ],
              ),
            );
          },
        );
      });
}
