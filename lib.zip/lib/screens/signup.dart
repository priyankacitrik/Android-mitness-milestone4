import 'package:flutter/widgets.dart';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_signin_button/button_list.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:intl/intl.dart';
import 'package:mitness/Constant/loader.dart';
import 'package:mitness/Constant/rest_ds.dart';
import 'package:mitness/InputData/inputData.dart';
import 'package:mitness/model/signup.dart';
import 'package:mitness/utils/constants.dart';
import 'package:mitness/validation/validation.dart';

import 'dart:io' show Platform;

import 'loginscreen.dart';


class SignupScreen extends StatefulWidget {

  @override
  AccountState createState() => AccountState();


}

class AccountState extends State<SignupScreen> {

  double _height;
  double _width;
  bool loading = false;
  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  TextEditingController confirmPasswordController = new TextEditingController();

  DateTime selectedDate = DateTime.now();
  DateTime selectedDate_to = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay(hour: 00, minute: 00);


  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  RestDataSource api = new RestDataSource();


  final TextEditingController _fnamecontroller = TextEditingController();
  TextEditingController _dateController = TextEditingController();
  final TextEditingController _mobilePhoneController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController emailcontroller = TextEditingController();
  final TextEditingController gendercontroller = TextEditingController();
  final TextEditingController dobcontroller = TextEditingController();
  final TextEditingController heightcontroller = TextEditingController();
  final TextEditingController weightcontroller = TextEditingController();
  final TextEditingController pwdcontroller = TextEditingController();
  final TextEditingController confmpwdcontroller = TextEditingController();
  final TextEditingController rolecontroller = TextEditingController();


  @override
  void initState() {
    super.initState();
  //  doRegistration( _fnamecontroller.text, _lastNameController.text, emailController.text,rolecontroller.text, pwdcontroller.text);

  }

  Future<Null> _selectDate(BuildContext context) async {
    print("fgfgfgg");
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        initialDatePickerMode: DatePickerMode.day,
        firstDate: DateTime(1650),
        lastDate: DateTime(2101));
    if (picked != null)
      setState(() {
        selectedDate = picked;
        _dateController.text = DateFormat.yMd().format(selectedDate);
      });
  }
  final scaffoldKey = GlobalKey<ScaffoldState>();
  GlobalKey<FormState> _key = new GlobalKey();
  bool _validate = false;

  validateData() {
    print("dfdfdf");

    if (_key.currentState.validate()) {
      if (pwdcontroller.text == confmpwdcontroller.text){
        addData();
        _key.currentState.save();
      }
      else{
        showAlertDialog(context, "Confirm Password","Passwords are not same");
        setState(() {
          _validate = true;
        });
      }
    } else {
      // validation error
      setState(() {
        _validate = true;
      });
    }
  }

  Future addData() {

    setState(() {
      loading = true;
    });

   doRegistration( _fnamecontroller.text, _lastNameController.text, emailController.text,rolecontroller.text, pwdcontroller.text);
  }

  Future navigatePage() {
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginScreen()));
  }
  doRegistration( String name, String lname, String email, String role, String password) async {
    api.doRegistration(name,lname,email,role,password).then((signup user) {

      Future.delayed(Duration(seconds: 2), () {
        setState(() {
          loading = false;
        });

        if (user.returnCode.toString()=='Success') {
         showAlertDialog2(context,user.returnMsg.toString());
         // navigatePage();

        }
        else{
          showAlertDialog1(context,user.returnMsg.toString());
        }

      });

    }).catchError((Object error) => () {
      print(error.toString());
      setState(() {
        loading = false;

      });
    });
  }
  showAlertDialog1(BuildContext context ,String msg) {

    // set up the button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {


        Navigator.of(context).pushReplacement(
            new MaterialPageRoute(builder: (context) => new SignupScreen()));


      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Mitness",style: new TextStyle(
        color: Colors.purple,
        fontSize: 16.0,

      ),),
      content: Text(msg),
      actions: [
        okButton,

      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlertDialog2(BuildContext context ,String msg) {

    // set up the button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {


        Navigator.of(context).pushReplacement(
            new MaterialPageRoute(builder: (context) => new LoginScreen()));


      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Mitness",style: new TextStyle(
        color: Colors.purple,
        fontSize: 16.0,

      ),),
      content: Text(msg),
      actions: [
        okButton,

      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  double height;
  double width;
  var size;
  bool _checkboxListTile = false;
  @override
  Widget build(BuildContext context) {
    MediaQueryData media = MediaQuery.of(context);

    return Stack(
      children: <Widget>[registerUi(context), loading ? Loader(loadingTxt: 'Please wait..'): Container()],
    );
  }

  @override
  Widget registerUi(BuildContext context) {
    _height = MediaQuery.of(context).size.height;
    _width = MediaQuery.of(context).size.width;
    TextStyle textStyle = Theme
        .of(context)
        .textTheme
        .bodyText1;

    return WillPopScope(
      onWillPop: () {
        // For when user presses Back navigation button in device navigationBar (Android)
        _returnToHomePage(false);
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        body: Form(
            key: _key,
            autovalidate: _validate,
            child: Stack(
                children: <Widget>[
                  Container(
                    height: double.infinity,
                    width: double.infinity,

                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: const AssetImage(
                            'assets/images/background.png'),
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),


                  Container(
                    height: MediaQuery.of(context).size.height,
                    child: SingleChildScrollView(
                      physics: AlwaysScrollableScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(height: 70,),
                          Container(
                            width:70,
                            height: 70,
                            margin: EdgeInsets.fromLTRB(10, 2.0, 3.0, 4.0),
                            alignment: Alignment.topLeft,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: const AssetImage('assets/logo/logo.png'),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 3.0, 10),
                        child:  Text("Sign up to Mitness",style: TextStyle(color: Color(0xffffffff),fontSize: 16,fontWeight: FontWeight.bold),),
                      ),


                          Wrap( direction: Axis.vertical,
                            spacing: 10,
                            children: <Widget>[

                            ],),

                          Container(
                            padding: EdgeInsets.fromLTRB(20, 10, 20, 0),

                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),

                              boxShadow: [
                                BoxShadow(
                                  color: Colors.transparent,
                                  blurRadius: 6.0,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Column(
                              children: <Widget>[
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    InkWell(
                                      onTap: () {

                                      },
                                      child: Container(
                                        width: _width/2.3,
                                        height: _height / 12,
                                        margin: EdgeInsets.only(top: 10),
                                        alignment: Alignment.center,

                                        child: TextFormField(
                                          style: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          textAlign: TextAlign.center,
                                          enabled: true,
                                          keyboardType: TextInputType.text,
                                          controller: _fnamecontroller,
                                          validator: ValidationData.firstNameValidate,
                                          onSaved: (String val) {

                                          },
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            disabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),

                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            focusedErrorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color : const Color(0xfff5f5f5))
                                            ),
                                            labelText: 'First name',
                                            labelStyle: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),

                                    InkWell(
                                      onTap: () {

                                      },
                                      child: Container(
                                        width: _width/2.3,
                                        height: _height / 12,
                                        margin: EdgeInsets.only(top: 10),
                                        alignment: Alignment.center,

                                        child: TextFormField(
                                          style: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          textAlign: TextAlign.center,
                                          controller: _lastNameController,
                                          validator: ValidationData.firstNameValidate,
                                          onSaved: (String val) {

                                          },
                                          enabled: true,
                                          keyboardType: TextInputType.text,

                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            disabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),

                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xff003366))
                                            ),
                                            focusedErrorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color : const Color(0xff003366))
                                            ),


                                            labelText: 'Last name',
                                            labelStyle: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          ),
                                        ),
                                      ),
                                    ),



                                  ],


                                ),
                                SizedBox(height: 10.0),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    InkWell(
                                      onTap: () {

                                      },
                                      child: Container(
                                        width: _width/2.3,
                                        height: _height / 12,
                                        margin: EdgeInsets.only(top: 10),
                                        alignment: Alignment.center,

                                        child: TextFormField(
                                          style: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          textAlign: TextAlign.center,
                                          enabled: true,
                                          keyboardType: TextInputType.text,
                                          controller: gendercontroller,

                                          onSaved: (String val) {

                                          },
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            disabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),

                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            focusedErrorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color : const Color(0xfff5f5f5))
                                            ),
                                            labelText: 'Gender',
                                            labelStyle: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),

                                    InkWell(
                                      onTap: () {
                                        _selectDate(context);
                                      },
                                      child: Container(
                                        width: _width/2.3,
                                        height: _height / 12,
                                        margin: EdgeInsets.only(top: 10),
                                        alignment: Alignment.center,

                                        child: TextFormField(
                                          style: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          textAlign: TextAlign.center,
                                          onSaved: (String val) {

                                          },
                                          enabled: false,
                                          keyboardType: TextInputType.number,

                                          controller: _dateController,

                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            disabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),

                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            focusedErrorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color : const Color(0xfff5f5f5))
                                            ),


                                            labelText: 'Date of birth',
                                            labelStyle: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          ),
                                        ),
                                      ),
                                    ),



                                  ],


                                ),
                                SizedBox(height: 10.0),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    InkWell(
                                      onTap: () {

                                      },
                                      child: Container(
                                        width: _width/2.3,
                                        height: _height / 12,
                                        margin: EdgeInsets.only(top: 10),
                                        alignment: Alignment.center,

                                        child: TextFormField(
                                          style: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          textAlign: TextAlign.center,
                                          enabled: true,
                                          keyboardType: TextInputType.number,
                                          controller: heightcontroller,

                                          onSaved: (String val) {

                                          },
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            disabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),

                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            focusedErrorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color : const Color(0xfff5f5f5))
                                            ),
                                            labelText: 'Height',
                                            labelStyle: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),

                                    InkWell(
                                      onTap: () {

                                      },
                                      child: Container(
                                        width: _width/2.3,
                                        height: _height / 12,
                                        margin: EdgeInsets.only(top: 10),
                                        alignment: Alignment.center,

                                        child: TextFormField(
                                          style: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          textAlign: TextAlign.center,
                                          controller: weightcontroller,
                                          onSaved: (String val) {

                                          },
                                          enabled: true,
                                          keyboardType: TextInputType.number,

                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            disabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),

                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            focusedErrorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color : const Color(0xfff5f5f5))
                                            ),


                                            labelText: 'Weight',
                                            labelStyle: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          ),
                                        ),
                                      ),
                                    ),



                                  ],


                                ),
                                SizedBox(height: 10.0),
                                InputData.buildLastNameTF(emailController),
                                SizedBox(height: 10.0),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [

                                    InkWell(
                                      onTap: () {

                                      },
                                      child: Container(
                                        width: _width/2.3,
                                        height: _height / 12,
                                        margin: EdgeInsets.only(top: 10),
                                        alignment: Alignment.center,

                                        child: TextFormField(
                                          style: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          textAlign: TextAlign.center,
                                          enabled: true,
                                          keyboardType: TextInputType.visiblePassword,
                                          controller: pwdcontroller,
                                          validator: ValidationData.firstNameValidate,

                                          onSaved: (String val) {

                                          },
                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            disabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),

                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            focusedErrorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color : const Color(0xfff5f5f5))
                                            ),
                                            labelText: 'Password',
                                            labelStyle: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),

                                    InkWell(
                                      onTap: () {

                                      },
                                      child: Container(
                                        width: _width/2.3,
                                        height: _height / 12,
                                        margin: EdgeInsets.only(top: 10),
                                        alignment: Alignment.center,

                                        child: TextFormField(
                                          style: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          textAlign: TextAlign.center,
                                          onSaved: (String val) {

                                          },
                                          enabled: true,
                                          keyboardType: TextInputType.visiblePassword,
                                          controller: confmpwdcontroller,

                                          decoration: InputDecoration(
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            disabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(Radius.circular(4)),
                                              borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5)),
                                            ),

                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            errorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color: const Color(0xfff5f5f5))
                                            ),
                                            focusedErrorBorder: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(Radius.circular(4)),
                                                borderSide: BorderSide(width: 1,color : const Color(0xfff5f5f5))
                                            ),


                                            labelText: 'Confirm Password',
                                            labelStyle: TextStyle(fontSize: 16,color : const Color(0xfff5f5f5)),
                                          ),
                                        ),
                                      ),
                                    ),



                                  ],


                                ),
                                SizedBox(height: 10.0),
                                InputData.buildNumberTF(_mobilePhoneController),
                                SizedBox(height: 10.0),
                                InputData.buildEmailTF(rolecontroller),
                                SizedBox(
                                  height: 10.0,
                                ),
                                Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 0.0,
                                      vertical: 10.0,
                                    ),

                                    child:Container(
                                      height: 50.0,
                                      child: RaisedButton(
                                        onPressed: () {
                                          validateData();
                                        },
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40.0)),
                                        padding: EdgeInsets.all(0.0),
                                        child: Ink(
                                          decoration: BoxDecoration(
                                              gradient: LinearGradient(colors: [Color(0xff8556d3), Color(0xffe67dae)],
                                                begin: Alignment.centerLeft,
                                                end: Alignment.centerRight,
                                              ),
                                              borderRadius: BorderRadius.circular(10.0)
                                          ),
                                          child: Container(
                                            constraints: BoxConstraints(maxWidth: 300.0, minHeight: 50.0),
                                            alignment: Alignment.center,
                                            child: Text(
                                              "Sign up",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: Colors.white,fontWeight: FontWeight.bold
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                ),

                                Text(
                                  '- OR -',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                                Expanded(
                                  flex: 0,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      // CircularProgressIndicator(),
                                      Padding(
                                        padding: EdgeInsets.only(top: 10.0),
                                      ),
                                      SignInButton(
                                        Buttons.FacebookNew,
                                        onPressed: () {
                                          // _showButtonPressDialog(context, 'FacebookNew');
                                        },
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(top: 20.0),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                              ],
                            ),
                          ),


                        ],


                      ),
                    ),
                  )

                ]

            )


        ),

        appBar:  AppBar(
          elevation: 10, backgroundColor: Colors.transparent,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pushReplacement(
                new MaterialPageRoute(builder: (context) => new LoginScreen()))

          ),
          actions: [
            /*IconButton(
              icon: Icon(
                Icons.qr_code_outlined,
                color: Colors.white,
              ),
              onPressed: () {
                // do something
              },
            )*/
          ],
        ),
        // body:
      ),
    );
  }


  InputDecoration _inputDecoration(TextStyle textStyle, String text) {
    return InputDecoration(
      labelText: text,
      labelStyle: textStyle,
      errorStyle: TextStyle(color: const Color(0xFFC1B65D), fontSize: 14.0),
      border: InputBorder.none,);
  }

/*
  void _saveorUpdateContact() async {
    if (_appBarTitle != "Add Contact") {
      try {
        await _model.updateContact(_contact);
        _returnToHomePage(true);
      } catch (e) {
        print(e);
        showAlertDialog(context, 'Status', 'Error updating contact.');
      }
    } else {
      try {
        await _model.insertContact(_contact);
        _returnToHomePage(true);
      } catch (e) {
        print(e);
        showAlertDialog(context, 'Status', 'Error adding contact.');
      }
    }
  }
*/

  void _returnToHomePage(bool refreshListDisplay) {
    Navigator.pop(context, refreshListDisplay);
  }

}

void showAlertDialog(BuildContext context, String title, String message) {
  AlertDialog alertDialog = AlertDialog(
    title: Text(title),
    content: Text(message),
  );
  showDialog(context: context, builder: (_) => alertDialog);
}
