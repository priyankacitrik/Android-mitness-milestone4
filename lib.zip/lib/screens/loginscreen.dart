import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_signin_button/button_list.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:mitness/Constant/rest_ds.dart';
import 'package:mitness/model/login.dart';
import 'package:mitness/screens/forgotpwd.dart';
import 'package:mitness/screens/qrcode.dart';
import 'package:mitness/screens/scanqrcode.dart';
import 'package:mitness/screens/signup.dart';
import 'package:mitness/utils/constants.dart';
import 'package:mitness/utils/loader.dart';
import 'package:mitness/utils/size_config.dart';
import 'package:mitness/validation/validation.dart';

import '../InputData/inputData.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _rememberMe = false;
  bool _obscureText = true;
  bool _obscureToggle = false;


  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  bool loading = false;
  RestDataSource api = new RestDataSource();
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }

  Widget _buildForgotPasswordBtn() {
    return Container(
      alignment: Alignment.topCenter,
      child: FlatButton(
        onPressed: () => Navigator.of(context).pushReplacement(
            new MaterialPageRoute(builder: (context) => new ForgotpasswordScreen())),
        padding: EdgeInsets.only(right: 0.0,top: 5),
        child: Text(
          'Forgot Your Password?',
          style: kLabelStyle,
        ),
      ),
    );
  }

  Widget _buildSignInWithText() {
    return Column(
      children: <Widget>[
        Text(
          '- OR -',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w400,
          ),
        ),
        SizedBox(height: 5.0),
        Text(
          'Sign in with',
          style: kLabelStyle,
        ),
      ],
    );
  }

  Widget _buildSocialBtn(Function onTap, AssetImage logo) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 60.0,
        width: 60.0,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black26,
              offset: Offset(0, 2),
              blurRadius: 6.0,
            ),
          ],
          image: DecorationImage(
            image: logo,
          ),
        ),
      ),
    );
  }

  Widget _buildSocialBtnRow() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          _buildSocialBtn(
                () => print('Login with Facebook'),
            AssetImage(
              'assets/logos/facebook.jpg',
            ),
          ),
          _buildSocialBtn(
                () => print('Login with Google'),
            AssetImage(
              'assets/logos/google.jpg',
            ),
          ),
        ],
      ),
    );
  }

  final scaffoldKey = GlobalKey<ScaffoldState>();
  GlobalKey<FormState> _key = new GlobalKey();
  bool _validate = false;

  validateData() {
    if (_key.currentState.validate()) {

      addData();

      _key.currentState.save();
    } else {
      // validation error
      setState(() {
        _validate = true;
      });
    }
  }

  Future addData() {
    print("Email:${emailController.text}");
    print("Password:${passwordController.text}");
    setState(() {
      loading =  true;
    });
    doLogin( emailController.text, passwordController.text);

  }

  doLogin(  String email,  String password) async {
    api.doLogin(email,password).then((login user) {

      Future.delayed(Duration(seconds: 2), () {
        setState(() {
          loading = false;
        });

        if (user.code.toString()=='Su') {

           navigatePage();

        }
        else{
          showAlertDialog1(context,user.msg.toString());
        }

      });

    }).catchError((Object error) => () {
      print(error.toString());
      setState(() {
        loading = false;

      });
    });
  }

  showAlertDialog1(BuildContext context ,String msg) {

    // set up the button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {


        Navigator.of(context).pushReplacement(
            new MaterialPageRoute(builder: (context) => new LoginScreen()));


      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Mitness",style: new TextStyle(
        color: Colors.purple,
        fontSize: 16.0,

      ),),
      content: Text(msg),
      actions: [
        okButton,

      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  Future navigatePage() {
    Navigator.of(context).pushReplacement(
        new MaterialPageRoute(builder: (context) => new QRcodeScreen()));
  }



 // double height;
 // double width;
  var size;
  bool _checkboxListTile = false;


  @override
  Widget build(BuildContext context) {
    MediaQueryData media = MediaQuery.of(context);
    size = media.size;


    return Stack(
      children: <Widget>[registerUi(context), loading ? Loader(loadingTxt: 'Please wait..'): Container()],
    );
  }

  Widget registerUi(BuildContext context) {
    if (MediaQuery.of(context).orientation == Orientation.portrait) {
      print("portrait");
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.portraitDown,
        DeviceOrientation.portraitUp,
      ]);

      // MediaQuery.of(context).orientation == Orientation.landscape;
    }
    else{
      print("landscpae");
    }



      return Scaffold(
          resizeToAvoidBottomInset : false,
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: true,
          key: scaffoldKey,
          appBar: AppBar(
            elevation: 10, backgroundColor: Colors.transparent,
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
            actions: [

            ],
          ),
          body:Form(
            key: _key,
            autovalidate: _validate,
            child: AnnotatedRegion<SystemUiOverlayStyle>(
              value: SystemUiOverlayStyle.light,
              child: GestureDetector(
                onTap: () => FocusScope.of(context).unfocus(),
                child: Stack(
                  children: <Widget>[
                    Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: const AssetImage( 'assets/images/background.png'),
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),


                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 10.0,
//                      vertical: 40.0,
                      ),

                      child : SingleChildScrollView(
                        physics: AlwaysScrollableScrollPhysics(),
                        padding: EdgeInsets.symmetric(
                          horizontal: 2.0,

                        ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          SizedBox(height: 80,),
                          Container(
                            width: 100,
                            height: 100,
                            alignment: Alignment.topCenter,
                            decoration: BoxDecoration(

                              image: DecorationImage(
                                image: const AssetImage('assets/logo/logo.png'),
                                fit: BoxFit.fill,

                              ),
                            ),
                          ),
                          SizedBox(height: 5,),
                          Center(
                            child: Text("Welcome back to mitness app",textAlign: TextAlign.center,
                              style:TextStyle(fontSize: 15,color: Colors.white
                              ),),
                          ),
                          SizedBox(height: 5,),
                          Container(

                            padding: EdgeInsets.symmetric(
                              horizontal: 10.0,
                              vertical: 5.0,
                            ),
                            //height: MediaQuery.of(context).size.height,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Colors.transparent,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black12,
                                  blurRadius: 6.0,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Column(
                              children: <Widget>[


                                SizedBox(height: 10.0),
                                InputData.buildLastNameTF(emailController),
                                SizedBox(
                                  height: 10.0,
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
/*
       Text(
         'Password',
         style: kLabelStyle,
       ),
*/
                                    SizedBox(height: 10.0),
                                    Container(
                                      alignment: Alignment.centerLeft,
                                      decoration: kBoxDecorationStyle,
                                      height: 60.0,
                                      child:  TextFormField(
                                        controller: passwordController,
                                        obscureText: _obscureText,
                                        style: TextStyle(
                                          color: const Color(0xfff5f5f5),
                                          fontFamily: 'OpenSans',
                                        ),
                                        validator: ValidationData.passwordValidate,

                                        decoration: InputDecoration(
                                          border: InputBorder.none,
                                          contentPadding: EdgeInsets.only(top: 14.0),
                                          prefixIcon: Icon(
                                            Icons.lock,
                                            color: const Color(0xffffffff),
                                          ),
                                          hintText: 'Password',
                                          hintStyle: kHintTextStyle,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                _buildForgotPasswordBtn(),
                               /* SizedBox(
                                    height: 50,
                                    width: 50,
                                    child:CheckboxListTile(
                                      controlAffinity: ListTileControlAffinity.leading,
                                      title: Text('Remember Me',style: kLabelLightStyle,),
                                      value: _checkboxListTile,
                                      onChanged: (value) {
                                        setState(() {
                                          _checkboxListTile = !_checkboxListTile;
                                        });
                                      },
                                    ),
                                ),*/


                              /*  CheckboxListTile(
                                  controlAffinity: ListTileControlAffinity.leading,
                                  title: Text('Show Password',style: kLabelLightStyle,),
                                  value: _obscureToggle,
                                  onChanged: (value) {
                                    setState(() {
                                      _obscureText = !_obscureText;
                                      _obscureToggle = !_obscureToggle;
                                    });
                                  },
                                ),*/

                                new Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 0.0,
                                    vertical: 10.0,
                                  ),

                                  child:Container(
                                    height: 50.0,
                                    child: RaisedButton(
                                      onPressed: () {
                                       validateData();
                                      },
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40.0)),
                                      padding: EdgeInsets.all(0.0),
                                      child: Ink(
                                        decoration: BoxDecoration(
                                            gradient: LinearGradient(colors: [Color(0xff8556d3), Color(0xffe67dae)],
                                              begin: Alignment.centerLeft,
                                              end: Alignment.centerRight,
                                            ),
                                            borderRadius: BorderRadius.circular(10.0)
                                        ),
                                        child: Container(
                                          constraints: BoxConstraints(maxWidth: 300.0, minHeight: 50.0),
                                          alignment: Alignment.center,
                                          child: Text(
                                            "Login",
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                                color: Colors.white
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  )
                                ),

                               /* Text(
                                  '- OR -',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),*/
                                Expanded(
                                  flex: 0,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      // CircularProgressIndicator(),
                                      Padding(
                                        padding: EdgeInsets.only(top: 10.0),
                                      ),
                                      SignInButton(
                                        Buttons.FacebookNew,
                                        onPressed: () {
                                         // _showButtonPressDialog(context, 'FacebookNew');
                                        },
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(top: 20.0),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                InkWell(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text("Dnon't have an account ?",style: TextStyle(color: Color(0xffffffff))),
                                      Text("Sign Up",style: TextStyle(color: Color(0xffe67dae)),),
                                    ],
                                  ),
                                  onTap: (){

                                    Navigator.of(context).pushReplacement(
                                        new MaterialPageRoute(builder: (context) => new SignupScreen()));

                                  },
                                ),
                              ],
                            ),
                          ),

/*
                        Container(
                          height: 200,
                        ),
*/
                        ],



                      ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ));





  }

  showAlertDialog(BuildContext context ,String msg) {

    // set up the button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {


        Navigator.of(context).pushReplacement(
            new MaterialPageRoute(builder: (context) => new LoginScreen()));


      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("APP",style: new TextStyle(
        color: Colors.purple,
        fontSize: 16.0,

      ),),
      content: Text(msg),
      actions: [
        okButton,

      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  Future setAuthValue(String value,String cust_id,String mobileno) async {

  }

}

