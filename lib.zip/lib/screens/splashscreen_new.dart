import 'dart:async';

import 'package:flutter/material.dart';
import 'package:mitness/screens/loginscreen.dart';

import 'OnBoardingPage.dart';
import 'chart.dart';
import 'home.dart';
import 'homescreen.dart';




class SplashScreen_ extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}


class _SplashScreenState extends State<SplashScreen_> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTimer();
  }
  @override
  Widget build(BuildContext context) {


    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Container(
            constraints: BoxConstraints.expand(),
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: const AssetImage('assets/images/splash_bg.png'),
                    fit: BoxFit.cover)
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 1,
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        height: 200,
                      width: 300,
                        child:  Image.asset(
                        'assets/logo/logo.png',




                      ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 10.0),
                      ),

                    ],
                  ),
                ),
              ),
              Expanded(
                flex: 0,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                   // CircularProgressIndicator(),
                    Padding(
                      padding: EdgeInsets.only(top: 20.0),
                    ),
                    Text(
                      "TRAIN WITH MITNESS",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.0,

                      ),

                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 20.0),
                    ),
                  ],
                ),
              )

            ],
          )
        ],
      ),
    );


  }

  void startTimer() {
    print("sddd");
    Timer(Duration(seconds: 3), () {
      navigateUser(); //It will redirect  after 3 seconds
    });
  }

  void navigateUser() async{
    print("fgfgg");
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) =>HomeScreen()));

  }
}