import 'package:carousel_slider/carousel_slider.dart';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mitness/Constant/rest_ds.dart';
import 'package:mitness/model/programs_homescreen.dart';
import 'package:mitness/screens/section_title.dart';
import 'package:mitness/screens/statiscsscreen.dart';
import 'package:mitness/utils/size_config.dart';
import 'package:mitness/widgets/CategoryItem.dart';

import 'contents.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomeScreen> with TickerProviderStateMixin  {
  List bannerAdSlider = [
    "assets/banner1.jpg",
    "assets/banner2.jpg",
    "assets/banner3.jpg",
    "assets/banner4.jpg",
    "assets/banner5.jpg",
  ];
  bool loading = false;
  RestDataSource api = new RestDataSource();
  List<String> gridItems = [
    'Yoga',
    'Cycling',
    'Welness',
    'Meditation',
    'Yoga',
    'Cycling',
    'Welness',
    'Meditation',

  ];
  int _selectedIndex = 0;
  var my_color_variable =Colors.pinkAccent;

  _onSelected(int index) {
    setState(() => _selectedIndex = index);
  }

  GlobalKey<ScaffoldState> drawerKey = GlobalKey();
  TabController tabController;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    loadhomesceen("","");
  }

  loadhomesceen(  String email,  String password) async {
    api.load_homescreen(email,password).then((programs_homescreen user) {

      Future.delayed(Duration(seconds: 2), () {
        setState(() {
          loading = false;
        });

     print(user.programResult[0].classname);


      });

    }).catchError((Object error) => () {
      print(error.toString());
      setState(() {
        loading = false;

      });
    });
  }


  @override
  Widget build(BuildContext context) {
    tabController = new TabController(length: 3, vsync: this);
    return Scaffold(
      backgroundColor: Colors.black87,
      key: drawerKey,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Home",
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.black54.withOpacity(0.5),
        brightness: Brightness.light,
        elevation: 0,
        actionsIconTheme: IconThemeData(color: Colors.black),
        iconTheme: IconThemeData(color: Colors.white),
        leading: IconButton(
          onPressed: () {},
          icon: Icon(EvaIcons.search),
        ),
        actions: <Widget>[
          IconButton(
            onPressed: () {
              drawerKey.currentState.openDrawer();
            },
            icon: Icon(
              EvaIcons.menu,
              color: Colors.pinkAccent,
            ),
          ),
        ],
      ),
      drawerEdgeDragWidth: 0,
      drawer: Theme(
        data: Theme.of(context).copyWith(
      canvasColor: Colors.black.withOpacity(.9), //This will change the drawer background to blue.
      //other styles
    ),

    child:  Drawer(
        child: ListView(
          children: <Widget>[
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(
                color: Colors.pinkAccent.withOpacity(0.5),
                borderRadius: BorderRadius.circular(5),
              ),
              accountEmail: Text(
                "person@mail.com",
                style: TextStyle(
                  color: Colors.black,
                ),
              ),
              accountName: Text(
                "Allice",
                style: TextStyle(
                  color: Colors.black,
                ),
              ),
              currentAccountPicture: ClipRRect(
                borderRadius: BorderRadius.circular(70),
                child: Image(
                  image: NetworkImage(
                      "https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"),
                  width: 70,
                  height: 70,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(height: 10),
            ListTile(
              title: Text("Home",  style: TextStyle(
                color: Colors.pinkAccent,
              ),),
              leading: Icon(EvaIcons.homeOutline,color: Colors.white,),
                onTap: (){
                  Navigator.of(context).pushReplacement(
                      new MaterialPageRoute(builder: (context) => new HomeScreen()));

                }
            ),
            SizedBox(height: 10),
            ListTile(
              title: Text("List Of Programs",  style: TextStyle(
                color: Colors.pinkAccent,
              ),),
              leading: Icon(EvaIcons.personOutline,color: Colors.white,),
                onTap: (){
                  Navigator.of(context).pushReplacement(
                      new MaterialPageRoute(builder: (context) => new LisofProgramsScreen()));

                }
            ),
            SizedBox(height: 10),
            ListTile(
              title: Text("Contens",  style: TextStyle(
                color: Colors.pinkAccent,
              ),),
              leading: Icon(EvaIcons.bulbOutline,color: Colors.white,),
                onTap: (){
                  Navigator.of(context).pushReplacement(
                      new MaterialPageRoute(builder: (context) => new ContentsScreen()));

                }
            ),
            SizedBox(height: 10),
            ListTile(
              title: Text("Discover",  style: TextStyle(
                color: Colors.pinkAccent,
              ),),
              leading: Icon(EvaIcons.heartOutline,color: Colors.white,),
            ),
            SizedBox(height: 20),
          /*  Padding(
              padding: const EdgeInsets.all(8.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: AspectRatio(
                  aspectRatio: 16 / 5,
                  child: Image.asset(
                    "assets/banner8.jpg",
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),*/
          ],
        ),
      ),),
      body: Container(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(

            children: <Widget>[
              SizedBox(
                height: 30,
              ),
              // banner ad slider
                 CarouselSlider(
                  options: CarouselOptions(
                    aspectRatio: 2,
                    autoPlay: true,
                  ),
                  items: bannerAdSlider.map((i) {
                    return Builder(
                      builder: (BuildContext context) {
                        return AspectRatio(
                          aspectRatio: 2,
                          child: GestureDetector(
                            child: Container(
                              margin: EdgeInsets.only(right: 10),
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  image: DecorationImage(
                                    image: AssetImage(i),
                                    fit: BoxFit.cover,
                                  )),
                              child: Container(
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color:
                                    const Color(0xFF000000).withOpacity(0.5)),
                                child: Padding(
                                  padding: EdgeInsets.all(20.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: Text(
                                          "09:48 am",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15,
                                          ),
                                        ),
                                      ),
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            "\@saranjohn",
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 15,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                            "Yoga",
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 14),
                                          )
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
              SizedBox(
                height: 15,
              ),

              Column(children: [
                Center(child:  Container(
                  height: 60,
                  child: Container(

                    child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: gridItems.length, itemBuilder: (context, index) {



                      return
                        InkWell(
                            onTap: () {
                              if(index==0){
                                my_color_variable=Colors.pinkAccent;
                              }
                              else{
                                my_color_variable=Colors.white;
                              }
                            },
                            child:
                            Container(
                          color: Colors.transparent,
                          child: Center(
                            child: Column(children: [
                              Container(
                                height:50,
                                width: 150,
                                child: Row(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(right: 8.0),
                                      child: Icon(
                                        Icons.circle,
                                        size: 8,
                                        color: Colors.white70,
                                      ),
                                    ),
                                    Text(
                                      gridItems[index],
                                      style: TextStyle(
                                          color: my_color_variable,
                                          fontSize: 20
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                            ]),
                          )));
                    }),






                ),)
                )
              ]),
              SizedBox(
                height: 15,
              ),



              CarouselSlider(
                options: CarouselOptions(
                  aspectRatio: 10/9,

                ),
                items: bannerAdSlider.map((i) {
                  return Builder(
                    builder: (BuildContext context) {
                      return AspectRatio(
                        aspectRatio: 2,
                        child: GestureDetector(
                          child: Container(
                            width: 200,
                            margin: EdgeInsets.only(right: 15),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                image: DecorationImage(
                                  image: AssetImage(i),
                                  fit: BoxFit.cover,
                                )),
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color:
                                  const Color(0xFF000000).withOpacity(0.5)),
                              child: Padding(
                                padding: EdgeInsets.all(20.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: <Widget>[
                                    Align(
                                      alignment: Alignment.topLeft,
                                      child: Text(
                                        "09:48 am",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Text(
                                          "\@saranjohn",
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 15,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        Text(
                                          "Yoga",
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 14),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  );
                }).toList(),
              ),





              SizedBox(
                height: 10,
              ),

              Container(

                child: Text(
                  "Courses"
                      ""
                      ""
                      ""
                      ""
                      ""
                      ""
                      " for",
                  style: TextStyle(
                    color: Colors.white,fontSize: 18
                  ),
                ),
              ),

              SizedBox(
                height: 10,
              ),








            ],
          ),
        ),
      ),
    );



  }

  @override
  void didChangeDependencies() {











    
  }

  var listItem = new ListView.builder(
    itemCount: 20,
    itemBuilder: (BuildContext context, int index) {
      return new ListTile(
        title: new Card(
          elevation: 5.0,
          child: new Container(
            alignment: Alignment.center,
            margin: new EdgeInsets.only(top: 10.0, bottom: 10.0),
            child: new Text("ListItem $index"),
          ),
        ),
        onTap: () {
          showDialog(
              barrierDismissible: false,
              context: context,
              child: new CupertinoAlertDialog(
                title: new Column(
                  children: <Widget>[
                    new Text("ListView"),
                    new Icon(
                      Icons.favorite,
                      color: Colors.red,
                    ),
                  ],
                ),
                content: new Text("Selected Item $index"),
                actions: <Widget>[
                  new FlatButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: new Text("OK"))
                ],
              ));
        },
      );
    },
  );

  var gridView = new GridView.builder(
      itemCount: 20,
      gridDelegate:
      new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
      itemBuilder: (BuildContext context, int index) {
        return new GestureDetector(
          child: new Card(
            elevation: 5.0,
            child: new Container(
              alignment: Alignment.center,
              child: new Text('Item $index'),
            ),
          ),
          onTap: () {
            showDialog(
              barrierDismissible: false,
              context: context,
              child: new CupertinoAlertDialog(
                title: new Column(
                  children: <Widget>[
                    new Text("GridView"),
                    new Icon(
                      Icons.favorite,
                      color: Colors.green,
                    ),
                  ],
                ),
                content: new Text("Selected Item $index"),
                actions: <Widget>[
                  new FlatButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      child: new Text("OK"))
                ],
              ),
            );
          },
        );
      });
}
