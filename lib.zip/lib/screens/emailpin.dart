import 'package:flutter/widgets.dart';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_signin_button/button_list.dart';
import 'package:flutter_signin_button/button_view.dart';
import 'package:mitness/InputData/inputData.dart';
import 'package:mitness/screens/forgotpwd.dart';
import 'package:mitness/utils/constants.dart';
import 'package:sms_otp_auto_verify/sms_otp_auto_verify.dart';

import 'dart:io' show Platform;

import 'creating.dart';
import 'loginscreen.dart';


class EmailPinScreen extends StatefulWidget {

  @override
  AccountState createState() => AccountState();


}

class AccountState extends State<EmailPinScreen> {

  double _height;
  double _width;
  bool loading = false;
  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  TextEditingController confirmPasswordController = new TextEditingController();



  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _midNameController = TextEditingController();
  final TextEditingController _mobilePhoneController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _titleController = TextEditingController();


  @override
  void initState() {
    super.initState();
  }

  final scaffoldKey = GlobalKey<ScaffoldState>();
  GlobalKey<FormState> _key = new GlobalKey();
  bool _validate = false;

  validateData() {
    if (_key.currentState.validate()) {
      if (passwordController.text == confirmPasswordController.text){
        addData();
        _key.currentState.save();
      }
      else{
        showAlertDialog(context, "Confirm Password","Passwords are not same");
        setState(() {
          _validate = true;
        });
      }
    } else {
      // validation error
      setState(() {
        _validate = true;
      });
    }
  }

  Future addData() {
    print("Email:${emailController.text}");
    print("Password:${passwordController.text}");
    setState(() {
      loading = true;
    });
    String medium = "";
    if (Platform.isAndroid) {
      medium="Android";
    } else if (Platform.isIOS) {
      medium = "IOS";
    }
    //doRegistration(_titleController.text, _nameController.text, _mobilePhoneController.text, emailController.text, passwordController.text,medium);
  }

  Future navigatePage() {
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginScreen()));
  }


  double height;
  double width;
  var size;
  bool _checkboxListTile = false;

  @override
  Widget build(BuildContext context) {
    _height = MediaQuery.of(context).size.height;
    _width = MediaQuery.of(context).size.width;
    TextStyle textStyle = Theme
        .of(context)
        .textTheme
        .bodyText1;

    return WillPopScope(
      onWillPop: () {
        // For when user presses Back navigation button in device navigationBar (Android)
        _returnToHomePage(false);
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        body: Form(
            key: _key,
            autovalidate: _validate,
            child: Stack(
                children: <Widget>[
                  Container(
                    height: double.infinity,
                    width: double.infinity,

                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: const AssetImage(
                            'assets/images/background.png'),
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),


                  Container(
                    height: MediaQuery.of(context).size.height,
                    child: SingleChildScrollView(
                      physics: AlwaysScrollableScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(height: 70,),
                          Container(
                            width:70,
                            height: 70,
                            margin: EdgeInsets.fromLTRB(10, 2.0, 3.0, 4.0),
                            alignment: Alignment.topLeft,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: const AssetImage('assets/images/mail.png'),
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                      Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 3.0, 5),
                        child:  Text("Enter the 4 digit code sent you at ",style: TextStyle(color: Color(0xffffffff),fontSize: 22,fontWeight: FontWeight.normal),),
                      ),

                          Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 3.0, 10),
                            child:  Text("test@appstech.xyz",style: TextStyle(color: Color(0xffe5e5e5 ),fontSize: 15,),),
                          ),
                          Wrap( direction: Axis.vertical,
                            spacing: 10,
                            children: <Widget>[

                            ],),

                          Container(
                            padding: EdgeInsets.fromLTRB(20, 10, 20, 0),

                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),

                              boxShadow: [
                                BoxShadow(
                                  color: Colors.transparent,
                                  blurRadius: 6.0,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Column(
                              children: <Widget>[
                                SizedBox(height: 15.0),


                                TextFieldPin(
                                  filled: true,
                                  filledColor: Colors.grey,
                                  codeLength: 4,
                                  boxSize: 46,
                                  filledAfterTextChange: false,
                                  textStyle: TextStyle(fontSize: 16),
                                  borderStyle: OutlineInputBorder(
                                      borderSide: BorderSide.none,
                                      borderRadius: BorderRadius.circular(34)),

                                ),
                                SizedBox(height: 10.0),



                                Container(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: 0.0,
                                      vertical: 10.0,
                                    ),

                                    child:Container(
                                      height: 50.0,
                                      child: RaisedButton(
                                        onPressed: () {
                                          Navigator.of(context).pushReplacement(
                                              new MaterialPageRoute(builder: (context) => new CreateScreen()));
                                        },
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40.0)),
                                        padding: EdgeInsets.all(0.0),
                                        child: Ink(
                                          decoration: BoxDecoration(
                                              gradient: LinearGradient(colors: [Color(0xff8556d3), Color(0xffe67dae)],
                                                begin: Alignment.centerLeft,
                                                end: Alignment.centerRight,
                                              ),
                                              borderRadius: BorderRadius.circular(10.0)
                                          ),
                                          child: Container(
                                            constraints: BoxConstraints(maxWidth: 300.0, minHeight: 50.0),
                                            alignment: Alignment.center,
                                            child: Text(
                                              "Next",
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                  color: Colors.white,fontWeight: FontWeight.bold
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    )
                                ),



                                SizedBox(
                                  height: 20,
                                ),
                              ],
                            ),
                          ),


                        ],


                      ),
                    ),
                  )

                ]

            )


        ),

        appBar:  AppBar(
          elevation: 10, backgroundColor: Colors.transparent,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pushReplacement(
                new MaterialPageRoute(builder: (context) => new ForgotpasswordScreen()))

          ),
          actions: [

          ],
        ),
        // body:
      ),
    );
  }


  InputDecoration _inputDecoration(TextStyle textStyle, String text) {
    return InputDecoration(
      labelText: text,
      labelStyle: textStyle,
      errorStyle: TextStyle(color: const Color(0xFFC1B65D), fontSize: 14.0),
      border: InputBorder.none,);
  }

/*
  void _saveorUpdateContact() async {
    if (_appBarTitle != "Add Contact") {
      try {
        await _model.updateContact(_contact);
        _returnToHomePage(true);
      } catch (e) {
        print(e);
        showAlertDialog(context, 'Status', 'Error updating contact.');
      }
    } else {
      try {
        await _model.insertContact(_contact);
        _returnToHomePage(true);
      } catch (e) {
        print(e);
        showAlertDialog(context, 'Status', 'Error adding contact.');
      }
    }
  }
*/

  void _returnToHomePage(bool refreshListDisplay) {
    Navigator.pop(context, refreshListDisplay);
  }

}

void showAlertDialog(BuildContext context, String title, String message) {
  AlertDialog alertDialog = AlertDialog(
    title: Text(title),
    content: Text(message),
  );
  showDialog(context: context, builder: (_) => alertDialog);
}
