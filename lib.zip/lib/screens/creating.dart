import 'dart:async';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_shine/flutter_shine.dart';
import 'package:mitness/utils/size_config.dart';

import 'OnBoardingPage.dart';
import 'homescreen.dart';

class CreateScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ScreenThreeState();
  }
}

class _ScreenThreeState extends State<CreateScreen> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startTimer();
  }

  void startTimer() {
    print("sddd");
    Timer(Duration(seconds: 3), () {
      navigateUser(); //It will redirect  after 3 seconds
    });
  }

  void navigateUser() async{
    print("fgfgg");
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) =>HomeScreen()));

  }
  @override
  Widget build(BuildContext context) {


    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(


          /*Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[


              Container(
                height: 40,
                decoration: BoxDecoration(color: Colors.red,),

                child: Text("TRAIN WITH MITNESS",textAlign: TextAlign.center,
                  style:TextStyle(fontSize: 18,fontWeight: FontWeight.bold
                  ),),

              ),






            ],
          ),*/
            body: 
            Center(


                  child:  Container(
                        constraints: BoxConstraints.expand(),
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: const AssetImage('assets/images/background.png'),
                                fit: BoxFit.cover)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Center(child:  Image.asset(
                              'assets/logo/logo.png',

                              width: 200,
                              height: 150,

                            ),
                            ),
                            Text("Creating account....",textAlign: TextAlign.center,
                              style:TextStyle(fontSize: 15,fontWeight: FontWeight.normal,color: Color(0xffe5e5e5)
                              ),),

                          ],
                        )


                    )


            ),

        )
    );

  }
}
