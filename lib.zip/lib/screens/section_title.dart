import 'package:flutter/material.dart';



class SectionTitle extends StatelessWidget {
  const SectionTitle({
    Key key,
    @required this.title,
    @required this.press,
  }) : super(key: key);

  final String title;
  final GestureTapCallback press;

  @override
  Widget build(BuildContext context) {
    return Column(

      children: [
        Container(
          color: const Color(0xFF15274b),

          child: Column(
            children: <Widget>[
              Center(

                        child: Container(

                          child:
                          Text(
                            title,
                            textAlign: TextAlign.left,

                            style:TextStyle(fontSize: 18, color: const Color(0xFFeae2be),),

                          )
                        ),



                )



            ],
          ),
        ),


      ],
    );
  }
}
