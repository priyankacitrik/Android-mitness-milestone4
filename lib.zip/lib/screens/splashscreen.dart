import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_shine/flutter_shine.dart';
import 'package:mitness/utils/size_config.dart';

class SplashScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _ScreenThreeState();
  }
}

class _ScreenThreeState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {


    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(

          bottomNavigationBar: BottomAppBar(
            color: Colors.black12,
            child: new Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  height: 40,


                  child: Center(
                    child: Text("TRAIN WITH MITNESS",textAlign: TextAlign.center,
                      style:TextStyle(fontSize: 18,fontWeight: FontWeight.bold,color: Colors.white
                      ),),
                  )

                ),


              ],
            ),
          ),
          /*Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[


              Container(
                height: 40,
                decoration: BoxDecoration(color: Colors.red,),

                child: Text("TRAIN WITH MITNESS",textAlign: TextAlign.center,
                  style:TextStyle(fontSize: 18,fontWeight: FontWeight.bold
                  ),),

              ),






            ],
          ),*/
            body: 
            Center(


                  child:  Container(
                        constraints: BoxConstraints.expand(),
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: const AssetImage('assets/images/splash_bg.png'),
                                fit: BoxFit.cover)
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Center(child:  Image.asset(
                              'assets/logo/logo.png',

                              width: 1000,

                            ),
                            ),


                          ],
                        )


                    )


            ),

        )
    );

  }
}
