package com.appstech.mitness

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
